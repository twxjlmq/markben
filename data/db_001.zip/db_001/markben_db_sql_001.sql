CREATE TABLE `t_sys_corp` (
  `id` VARCHAR(50) NOT NULL COMMENT '主键ID',
  `state` INT(1) NOT NULL COMMENT '状态;1--有效；0--无效',
  `create_time` DATETIME NOT NULL COMMENT '创建时间',
  `name` VARCHAR(127) NOT NULL COMMENT '企业（组织）名称',
  `parent_id` VARCHAR(50) NOT NULL DEFAULT 0 COMMENT '父ID，默认值为：0',
  `sort_order` INT(5) NOT NULL DEFAULT 0 COMMENT '排序序号；默认为0',
  `logo` VARCHAR(255) NULL COMMENT '企业（组织）LOGO',
  `short_name` VARCHAR(127) NOT NULL COMMENT '企业简称；如果不设置该值时，其值和name字段值一致',
  `describe` VARCHAR(1000) NULL COMMENT '描述',
  `remarks` VARCHAR(500) NULL COMMENT '备注',
  `corp_user_id` VARCHAR(50) NOT NULL COMMENT '添加企业的企业用户ID；和t_sys_corp_user表中的主键ID关联',
  PRIMARY KEY (`id`))
COMMENT = '系统企业信息表';
