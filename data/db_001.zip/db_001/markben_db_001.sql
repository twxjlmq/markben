-- MySQL dump 10.13  Distrib 8.0.21, for Linux (x86_64)
--
-- Host: localhost    Database: markben
-- ------------------------------------------------------
-- Server version	8.0.21-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_sys_corp`
--

DROP TABLE IF EXISTS `t_sys_corp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_sys_corp` (
  `id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '主键ID',
  `state` int NOT NULL COMMENT '状态;1--有效；0--无效',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `name` varchar(127) COLLATE utf8mb4_general_ci NOT NULL COMMENT '企业（组织）名称',
  `parent_id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT '父ID，默认值为：0',
  `sort_order` int NOT NULL DEFAULT '0' COMMENT '排序序号；默认为0',
  `logo` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '企业（组织）LOGO',
  `short_name` varchar(127) COLLATE utf8mb4_general_ci NOT NULL COMMENT '企业简称；如果不设置该值时，其值和name字段值一致',
  `describe` varchar(1000) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '描述',
  `remarks` varchar(500) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  `corp_user_id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '添加企业的企业用户ID；和t_sys_corp_user表中的主键ID关联',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='系统企业信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_sys_corp`
--

LOCK TABLES `t_sys_corp` WRITE;
/*!40000 ALTER TABLE `t_sys_corp` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_sys_corp` ENABLE KEYS */;
UNLOCK TABLES;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-05 23:46:33
